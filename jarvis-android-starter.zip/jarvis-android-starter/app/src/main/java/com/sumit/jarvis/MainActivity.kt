package com.sumit.jarvis

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var logView: TextView
    private lateinit var input: EditText
    private var ttsReady = false
    private val prefs by lazy { getSharedPreferences("jarvis_memory", MODE_PRIVATE) }
    private val speechRequest = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        addLine("JARVIS", "नमस्ते Sumit! मैं तुम्हारा शुरुआती Android assistant हूँ। बोलो या नीचे लिखो।")
        val saved = prefs.getString("memory", "").orEmpty()
        if (saved.isNotBlank()) addLine("Memory", saved)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 32, 24, 24)
            setBackgroundColor(0xFF07111F.toInt())
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(0xFF65D9FF.toInt())
        }
        val subtitle = TextView(this).apply {
            text = "PERSONAL AI • VOICE • MEMORY"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(0xFFB8C7D9.toInt())
            setPadding(0, 4, 0, 18)
        }
        logView = TextView(this).apply {
            textSize = 16f
            setTextColor(0xFFF0F5FA.toInt())
            setPadding(14, 14, 14, 14)
        }
        val scroll = ScrollView(this).apply { addView(logView) }
        input = EditText(this).apply {
            hint = "यहाँ लिखो… (जैसे: search Patna weather)"
            setHintTextColor(0xFF8A9AAD.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setSingleLine(false)
        }
        val send = Button(this).apply { text = "Send"; setOnClickListener { process(input.text.toString()); input.setText("") } }
        val speak = Button(this).apply { text = "🎙 Speak"; setOnClickListener { startListening() } }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(send, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)); addView(speak, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)) }
        root.addView(title)
        root.addView(subtitle)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(input)
        root.addView(row)
        setContentView(root)
    }

    private fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS को अपना command बोलें")
        }
        try { startActivityForResult(intent, speechRequest) }
        catch (_: Exception) { Toast.makeText(this, "इस फोन पर speech recognition उपलब्ध नहीं है।", Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Android speech recognizer result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequest && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            input.setText(words)
            process(words)
            input.setText("")
        }
    }

    private fun process(raw: String) {
        val command = raw.trim()
        if (command.isBlank()) return
        addLine("You", command)
        val lower = command.lowercase(Locale.ROOT)
        when {
            lower.startsWith("remember ") || lower.startsWith("याद रखो ") || lower.startsWith("याद रखना ") -> {
                val note = command.substringAfter(' ').trim()
                prefs.edit().putString("memory", note).apply()
                reply("ठीक है, मैंने यह बात इस फोन में सेव कर दी: $note")
            }
            lower.contains("what do you remember") || lower.contains("क्या याद है") -> {
                reply(prefs.getString("memory", null)?.let { "मेरी सेव की हुई बात: $it" } ?: "अभी कोई बात सेव नहीं है। 'याद रखो ...' बोलकर सेव कर सकते हो।")
            }
            lower.contains("open settings") || lower.contains("सेटिंग") -> {
                reply("फोन की Settings खोल रहा हूँ।")
                try { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }
                catch (_: Exception) { reply("Settings नहीं खुल पाई।") }
            }
            lower.startsWith("search ") || lower.startsWith("खोजो ") || lower.startsWith("सर्च ") -> {
                val query = command.substringAfter(' ').trim()
                reply("इंटरनेट पर खोज खोल रहा हूँ: $query")
                val url = "https://www.google.com/search?q=" + java.net.URLEncoder.encode(query, "UTF-8")
                startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)))
            }
            lower.contains("time") || lower.contains("समय") || lower.contains("टाइम") -> {
                val now = java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date())
                reply("अभी समय है $now")
            }
            else -> reply("मैंने तुम्हारी बात समझी: $command. अभी इस starter version में AI chat के लिए सुरक्षित online backend जोड़ना बाकी है। फिलहाल 'search ...', 'याद रखो ...', या 'Settings खोलो' आज़माओ।")
        }
    }

    private fun reply(message: String) { addLine("JARVIS", message); if (ttsReady) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis-reply") }
    private fun addLine(who: String, message: String) { logView.append("\n$who\n$message\n") }
    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) { tts.language = Locale("hi", "IN"); ttsReady = true } }
    override fun onDestroy() { if (::tts.isInitialized) { tts.stop(); tts.shutdown() }; super.onDestroy() }
}
