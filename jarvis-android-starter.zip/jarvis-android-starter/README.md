# JARVIS Android Starter

This is an early native Android starter project for a personal assistant. It currently includes:
- Android speech recognition (device/service dependent)
- Spoken replies using Android Text-to-Speech
- Basic commands: open Android Settings, web search, tell the time
- One locally saved memory note using SharedPreferences
- GitHub Actions workflow to build a debug APK in the cloud

## Important limitations
- This is a starter, not a full Iron Man assistant.
- AI chat is not connected yet. Add it through a secure backend; do not embed a private AI API key in the Android APK.
- Speech recognition may require internet or a speech service, depending on the phone.
- Offline support is limited to commands that do not require web search or a remote AI model.
- Phone control is limited to Android-supported intents and user-granted permissions.

## Build on GitHub using a phone
1. Create a repository named `jarvis-android`.
2. Extract this ZIP on your phone.
3. In the repository page, use **Add file → Upload files** and upload the extracted files/folders. If the mobile browser cannot upload folders, open GitHub in Chrome's **Desktop site** mode, or use a cloud development environment.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab. Enable Actions if prompted.
6. Select **Build JARVIS Android APK** → **Run workflow**.
7. When the workflow succeeds, open the run, scroll to **Artifacts**, and download `jarvis-debug-apk`.
8. Extract the artifact ZIP to get `app-debug.apk`, then open it on your Android phone and approve installation if Android asks.

Only install APKs you built from source you trust. The debug APK is for testing, not Play Store release.
